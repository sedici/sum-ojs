googleAnalytics
===============

This is a plugin adding Google Analytics support to OMP 1.2+ and OJS 3.0+.

It is currently shipped with those versions of the software and does not need
to be installed separately.
