# Browse block plugin
This plugin implements a block plugin that allows the user to navigate content by categories.
It is compatible with OJS and OPS and is already included in those applications.
